package problem2;

public class ListOfStrings implements IListOfStrings {

  private Node headerNode;

  public ListOfStrings(Node headerNode) {
    this.headerNode = headerNode;
  }

  public Node getHeaderNode() {
    return this.headerNode;
  }

  @Override
  public Boolean isEmpty() {
    return headerNode == null;
  }

  @Override
  public Integer size() {
    if (this.isEmpty()) {
      return 0;
    } else {
      Integer size = 1;
      Node tempNode = this.headerNode;

      while (tempNode.getPointerToNext() != null) {
        size++;
        tempNode = tempNode.getPointerToNext();
      }
      return size;
    }
  }

  @Override
  public Boolean contains(String word) {
    if (this.isEmpty()) {
      return false;
    } else {
      Node tempNode = this.headerNode;
      while(tempNode.getValue() != null) {
        if (tempNode.getValue().equals(word)){
          return true;
        }
        tempNode = tempNode.getPointerToNext();
      }
    }
    return false;
  }

  @Override
  public Boolean containsAll(ListOfStrings words) {
    if (this.isEmpty() || words.isEmpty()) {
      return false;
    } else {
      Node tempNode = this.headerNode;
      while (tempNode.getPointerToNext() != null) {
        if (!words.contains(tempNode.getValue())) {
          return false;
        }
        tempNode = tempNode.getPointerToNext();
      }
    }
    return true;
  }

  @Override
  public IListOfStrings filterLargerThan() {
//    if(this.isEmpty())
//      return this;
//    else{
//      Node tempNode = this.headerNode;
//      ListOfStrings resultingList;
//      while(tempNode.getPointerToNext() != null)
//    }
    return null;
  }

  @Override
  public IListOfStrings addString(String element){
    Node tempNode = new Node(element, null);

    if(isEmpty()) {
      this.headerNode = tempNode;
      return this;
    }
    else{
      Node currentNode = headerNode;
      while(currentNode.getPointerToNext() != null){
        currentNode = currentNode.getPointerToNext();
      }
      currentNode.setPointerToNext(tempNode);
    }
    return this;
  }

  @Override
  public Boolean hasDuplicates(String word) {

    return null;
  }

  @Override
  public IListOfStrings removeDuplicates(String word) {
    return null;
  }
}
