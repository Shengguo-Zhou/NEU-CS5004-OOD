package problem1a;

public abstract class AbstractArtist implements IArtist {

  private final Integer MIN_AGE = 0;
  private final Integer MAX_AGE = 128;
  protected final Double LOAD_FACTOR = 0.75;
  protected Name name;
  protected Integer age;
  protected String[] genres;
  protected String[] awards;
  protected Integer numAwards;

  public AbstractArtist(Name name, Integer age)
      throws IllegalAgeException {
    this.name = name;
    this.validateAge(age);
    this.genres = new String[5];
    this.awards = new String[5];
    this.numAwards = 0;
  }

  private void validateAge(Integer age) throws IllegalAgeException {
    if (age < MIN_AGE || age > MAX_AGE) {
      throw new IllegalAgeException("Not a valid age.");
    } else {
      this.age = age;
    }
  }

  private Boolean calculateLoadFactor() {
    Double m = (double) this.numAwards;
    Double n = (double) this.awards.length;
    return (m/n) > this.LOAD_FACTOR;
  }

  // there is an error here, try running the code and observe what happens.
  @Override
  public AbstractArtist receiveAward(String award) throws IllegalAgeException {
    String[] newAwardsArray;
    // when the awards array is empty
    if (this.numAwards.equals(0)) {
      this.awards[0] = award;
      // when there isn't enough space in the array
    } else if (this.numAwards.equals(this.awards.length)) {
      newAwardsArray = new String[this.awards.length + 1];
      for (int i = 0; i < this.numAwards; i++) {
        newAwardsArray[i] = this.awards[i];
      }
      this.numAwards++;
      this.awards = newAwardsArray;
    } else {
      this.numAwards++;
      this.awards[this.numAwards] = award;
    }
    return this;
  }

  @Override
  public void receiveVoidAward(String award) {
    // autoboxing is occurring here, this.arrays.length returns an int
    // with autoboxing it will change it to an Integer object
    String[] newAwardsArray;
    // when the awards array is empty
    if (this.numAwards.equals(0)) {
      this.awards[0] = award;
      // when there isn't enought space in the array
    } else if (this.numAwards.equals(this.awards.length)) {
      newAwardsArray = new String[this.awards.length + 1];
      for (int i = 0; i < this.numAwards; i++) {
        newAwardsArray[i] = this.awards[i];
      }
      this.numAwards++;
      this.awards = newAwardsArray;
    } else {
      this.numAwards++;
      this.awards[this.numAwards] = award;
    }
  }

  private String[] resizeCopyArray(String[] pastAwards, String award) {
    String[] newAwardsArray = new String[this.awards.length + 10];
    int i;
    for (i = 0; i < this.numAwards; i++) {
      newAwardsArray[i] = pastAwards[i];
    }
    newAwardsArray[i] = award;
    return newAwardsArray;
  }

  @Override
  public void receiveVoidAwardLF(String award) {
    String[] newAwardsArray;
    // when the awards array is empty
    if (this.numAwards.equals(0)) {
      this.awards[0] = award;
      this.numAwards++;
      // when there isn't enough space in the array
    } else if (this.calculateLoadFactor()) {
      newAwardsArray = this.resizeCopyArray(this.awards, award);
      this.awards = newAwardsArray;
      this.numAwards++;
    } else {
      this.awards[this.numAwards] = award;
      this.numAwards++;
    }
  }

  // getters and setters
  public Name getName() {
    return name;
  }

  public Integer getAge() {
    return this.age;
  }

  public String[] getGenres() {
    return this.genres;
  }

  public String[] getAwards() {
    return this.awards;
  }

  public void setName(Name name) {
    this.name = name;
  }

  public void setAge(Integer age) {
    this.age = age;
  }

  public void setGenres(String[] genres) {
    this.genres = genres;
  }

  public void setAwards(String[] awards) {
    this.awards = awards;
  }

  public static void main(String[] args) throws IllegalAgeException {
    int i;
    for (i = 0; i < 5; i++) {
      System.out.println(i);
    }
    System.out.println(i);
  }

}
