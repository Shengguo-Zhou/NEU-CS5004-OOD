package problem1a;

public interface IArtist {

  AbstractArtist receiveAward(String award) throws IllegalAgeException;

  void receiveVoidAward(String award);

  void receiveVoidAwardLF(String name);

}
