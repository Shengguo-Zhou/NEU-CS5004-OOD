package problem1a;

public class IllegalAgeException extends Exception{

  public IllegalAgeException(String message) {
    super(message);
  }

}
