package problem1a;

public abstract class AbstractVisualEnt extends AbstractArtist {

  private String[] movies;
  private String[] series;
  private String[] multimedia;

  public AbstractVisualEnt(Name name, Integer age) throws IllegalAgeException {
    super(name, age);
    this.movies = movies;
    this.series = series;
    this.multimedia = multimedia;
  }
}
