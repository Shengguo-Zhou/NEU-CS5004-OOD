package problem1a;

import java.util.Arrays;

// implementation uses
public class Actor extends AbstractVisualEnt {

  private String[] movies;
  private String[] series;
  private String[] multimedia;

  public Actor(Name name, Integer age) throws IllegalAgeException {
    super(name, age);
    this.movies = new String[5];
    this.series = new String[5];
    this.multimedia = new String[5];
  }

  // how inheritance may be handy when you want to override a implemented code but want to make changes
  @Override
  public void receiveVoidAwardLF(String award) {
   super.receiveVoidAwardLF(award);
   System.out.println("The actor received the following awards: ");
   for (int i = 0; i < this.numAwards; i++) {
     System.out.println(" " + this.awards[i] + " ");
   }
   System.out.println(this.awards.length);
  }

  @Override
  public String toString() {
    return "Actor{" +
        "name=" + name +
        ", age=" + age +
        ", genres=" + Arrays.toString(genres) +
        ", awards=" + Arrays.toString(awards) +
        ", numAwards=" + numAwards +
        '}';
  }

  public static void main(String[] args) throws IllegalAgeException {
    Name gizmoName = new Name("Gizmo", "Puppy");
    Actor gizmo;
    gizmo = new Actor(gizmoName, 2);
    gizmo.receiveVoidAwardLF("1");
    gizmo.receiveVoidAwardLF("2");
    gizmo.receiveVoidAwardLF("3");
    gizmo.receiveVoidAwardLF("4");
    gizmo.receiveVoidAwardLF("5");
    gizmo.receiveVoidAwardLF("6");
    gizmo.receiveVoidAwardLF("7");

  }


}
